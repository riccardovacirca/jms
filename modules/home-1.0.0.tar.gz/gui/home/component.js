import { LitElement, html } from 'lit';
import { authorized, user } from '../../store.js';

export default class HomeComponent extends LitElement {

  static properties = {
    _hello:      { state: true },
    _authorized: { state: true },
    _user:       { state: true }
  };

  // Disabilita Shadow DOM: Bootstrap funziona normalmente
  createRenderRoot() { return this; }

  constructor() {
    super();
    this._hello      = null;
    this._authorized = authorized.get();
    this._user       = user.get();
  }

  connectedCallback() {
    super.connectedCallback();
    this._unsubAuthorized = authorized.subscribe(v => { this._authorized = v; });
    this._unsubUser       = user.subscribe(v => { this._user = v; if (v) this._loadHello(); else this._hello = null; });
  }

  disconnectedCallback() {
    super.disconnectedCallback();
    this._unsubAuthorized();
    this._unsubUser();
  }

  async _loadHello() {
    try {
      const res = await fetch('/api/home/hello');
      if (!res.ok) { this._hello = null; return; }
      const data = await res.json();
      if (!data.err) this._hello = data.out;
      else this._hello = null;
    } catch (e) {
      this._hello = null;
    }
  }

  async _logout() {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } finally {
      authorized.set(false);
      user.set(null);
    }
  }

  render() {
    return html`
      <div class="min-vh-100 bg-light">
        <header class="d-flex align-items-center px-4 py-3 bg-white border-bottom">
          <span class="fw-bold fs-5">App</span>
          <div class="ms-auto d-flex align-items-center gap-2">
            ${this._authorized
              ? html`
                  <span class="text-muted small">${this._user?.username}</span>
                  <button class="btn btn-sm btn-outline-danger" @click=${this._logout}>Esci</button>`
              : html`
                  <button class="btn btn-sm btn-outline-primary"
                          @click=${() => window.location.hash = '/auth'}>Accedi</button>`
            }
          </div>
        </header>
        <main class="container py-5">
          <div class="text-center py-5">
            <h1 class="display-5">Benvenuto</h1>
            ${this._hello ? html`<p class="text-muted">${this._hello}</p>` : ''}
          </div>
        </main>
      </div>
    `;
  }
}

customElements.define('home-component', HomeComponent);
