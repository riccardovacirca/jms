import 'bootstrap/dist/css/bootstrap.min.css';
import './home.css';
import HomeComponent from './component.js';

/**
 * Entry point del modulo home.
 * Espone un metodo mount() chiamato dal router.
 */
export default {
  /**
   * Monta il modulo nel container fornito
   * @param {HTMLElement} container - Container dove montare il modulo
   */
  mount(container) {
    const component = new HomeComponent();
    container.appendChild(component);
  }
};
