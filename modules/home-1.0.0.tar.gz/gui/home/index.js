import 'bootstrap/dist/css/bootstrap.min.css';
import './component.js';

export default {
  mount(container) {
    container.appendChild(document.createElement('home-component'));
  }
};
