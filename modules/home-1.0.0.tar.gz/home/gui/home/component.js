import { auth, logout } from '../../store.js';

/**
 * Web component del modulo home.
 * Mostra un messaggio di benvenuto recuperato dall'API /api/home/hello.
 */
export default class HomeComponent extends HTMLElement {
  connectedCallback() {
    this._render();
    this._loadHello();
    auth.subscribe(() => this._render());
  }

  /**
   * Carica il messaggio dall'endpoint /api/home/hello
   */
  async _loadHello() {
    try {
      const res = await fetch('/api/home/hello');
      const data = await res.json();
      const messageEl = this.querySelector('#hello-message');
      if (messageEl && !data.err) {
        messageEl.textContent = data.out;
      }
    } catch (e) {
      console.error('Failed to load hello message', e);
    }
  }

  /**
   * Renderizza il component
   */
  _render() {
    const { isAuthenticated, user } = auth.state;

    this.innerHTML = `
      <div class="min-vh-100 bg-light">
        <header class="d-flex align-items-center px-4 py-3 bg-white border-bottom">
          <span class="fw-bold fs-5">App</span>
          <div class="ms-auto d-flex align-items-center gap-2">
            ${isAuthenticated
              ? `<span class="text-muted small">${user?.username}</span>
                 <button class="btn btn-sm btn-outline-danger" id="btn-logout">Esci</button>`
              : `<button class="btn btn-sm btn-outline-primary" id="btn-login">Accedi</button>`
            }
          </div>
        </header>
        <main class="container py-5">
          <div class="text-center py-5">
            <h1 class="display-5">Benvenuto</h1>
            <p class="text-muted" id="hello-message">Caricamento...</p>
          </div>
        </main>
      </div>
    `;

    this.querySelector('#btn-logout')?.addEventListener('click', () => {
      console.info('[Home] User logout');
      logout();
    });

    this.querySelector('#btn-login')?.addEventListener('click', () => {
      window.location.hash = '/auth';
    });
  }
}

customElements.define('home-component', HomeComponent);
