package {{APP_PACKAGE}}.auth.handler;

import {{APP_PACKAGE}}.auth.dao.RefreshTokenDAO;
import dev.jms.util.DB;
import dev.jms.util.Handler;
import dev.jms.util.HttpRequest;
import dev.jms.util.HttpResponse;

/** Handler per il logout. Elimina il refresh token e cancella i cookie di sessione. */
public class LogoutHandler implements Handler
{
  /** Invalida il refresh token e svuota i cookie access_token e refresh_token. */
  @Override
  public void post(HttpRequest req, HttpResponse res, DB db) throws Exception
  {
    String refreshToken;

    refreshToken = req.getCookie("refresh_token");

    if (refreshToken != null) {
      new RefreshTokenDAO(db).delete(refreshToken);
    }

    res.status(200)
       .contentType("application/json")
       .cookie("access_token", "", 0)
       .cookie("refresh_token", "", 0)
       .err(false)
       .log(null)
       .out(null)
       .send();
  }
}
