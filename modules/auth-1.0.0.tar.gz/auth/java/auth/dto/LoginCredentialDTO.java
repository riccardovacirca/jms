package com.example.auth.dto;

public record LoginCredentialDTO(String username, String password) {}
