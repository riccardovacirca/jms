# Module: auth

> Replace `com.example` with your Maven groupId (e.g. `io.mycompany`).
> Replace `{{APP_PACKAGE_PATH}}` with the corresponding filesystem path (e.g. `io/mycompany`).

## Contents

- `java/auth/` — Java package `com.example.auth`
- `gui/auth/` — Frontend module (SPA, LitElement)
- `migration/` — Flyway SQL migrations

## Installation

### 1. Java sources

Copy `java/auth/` into your project's Java source tree:

```sh
cp -r java/auth/  src/main/java/{{APP_PACKAGE_PATH}}/auth/
```

Replace `com.example` in all copied Java files:

```sh
find src/main/java/{{APP_PACKAGE_PATH}}/auth -name '*.java' \
     -exec sed -i 's|com.example|your.package|g' {} +
```

### 2. Frontend sources

Copy `gui/auth/` into the Vite modules directory:

```sh
cp -r gui/auth/  vite/src/modules/auth/
```

### 3. Database migrations

Copy the SQL files into the Flyway migrations directory:

```sh
cp migration/*.sql  src/main/resources/db/migration/
```

### 4. pom.xml — dependencies

Add inside `<dependencies>` in `pom.xml`:

```xml
<dependency>
    <groupId>com.auth0</groupId>
    <artifactId>java-jwt</artifactId>
    <version>4.4.0</version>
</dependency>
```

### 5. application.properties — configuration keys

Add missing keys to `config/application.properties`:

```properties
jwt.secret=dev-secret-change-in-production
jwt.access.expiry.seconds=900
mail.enabled=false
mail.host=mailpit
mail.port=1025
mail.auth=false
mail.user=
mail.password=
mail.from=noreply@example.com
```

### 6. App.java — route registrations

Add imports at the top of `App.java`:

```java
import com.example.auth.handler.ChangePasswordHandler;
import com.example.auth.handler.ForgotPasswordHandler;
import com.example.auth.handler.LoginHandler;
import com.example.auth.handler.LogoutHandler;
import com.example.auth.handler.RefreshHandler;
import com.example.auth.handler.SessionHandler;
import com.example.auth.handler.TwoFactorHandler;
```

Add routes in the `PathTemplateHandler` chain:

```java
paths.add("/api/auth/login",           route(new LoginHandler(),          ds));
paths.add("/api/auth/session",         route(new SessionHandler(),        ds));
paths.add("/api/auth/logout",          route(new LogoutHandler(),         ds));
paths.add("/api/auth/refresh",         route(new RefreshHandler(),        ds));
paths.add("/api/auth/change-password", route(new ChangePasswordHandler(), ds));
paths.add("/api/auth/forgot-password", route(new ForgotPasswordHandler(), ds));
paths.add("/api/auth/2fa",             route(new TwoFactorHandler(),      ds));
```

### 7. Register route in config.js

Add the module configuration to `vite/src/config.js`:

```javascript
export const MODULE_CONFIG = {
  auth: {
    path: '/auth',
    authorization: null
  }
};
```

For routes that require authorization, set their redirect to `/auth`:

```javascript
home: {
  path: '/home',
  authorization: { redirectTo: '/auth' }
}
```

### 8. Build

Inside the dev container, rebuild the frontend and the backend:

```sh
cmd gui build
cmd app build
```

**Done!** The auth module handles login, session restore on page load, and token refresh.

## Behavior

- On mount: checks `/api/auth/session` — if valid, sets `authorized`/`user` and navigates to `DEFAULT_ROUTE`
- On login: sets `authorized.set(true)` and `user.set(data)`, navigates to `DEFAULT_ROUTE`
- On `must_change_password`: shows the change password form
- After password change: logs out server-side, returns to login form

## Dependencies

- Bootstrap CSS (imported in `index.js`)
- `authorized`, `user` from `../../store.js`
- `DEFAULT_ROUTE` from `../../config.js`
- `lit` (LitElement)
