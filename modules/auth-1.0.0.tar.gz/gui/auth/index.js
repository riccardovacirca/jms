import 'bootstrap/dist/css/bootstrap.min.css';
import './auth.css';
import LoginComponent from './login.js';
import ChangepassComponent from './changepass.js';

export default {
  mount(container) {
    const showLogin = () => {
      container.innerHTML = '';
      const login = new LoginComponent();
      login.addEventListener('must-change-password', () => {
        container.innerHTML = '';
        const changepass = new ChangepassComponent();
        changepass.addEventListener('password-changed', showLogin);
        container.appendChild(changepass);
      });
      container.appendChild(login);
    };
    showLogin();
  }
};
