import 'bootstrap/dist/css/bootstrap.min.css';
import './auth.css';
import { authorized, user } from '../../store.js';
import { DEFAULT_ROUTE } from '../../config.js';
import LoginComponent from './login.js';
import ChangepassComponent from './changepass.js';

export default {
  async mount(container) {
    // Verifica se esiste già una sessione valida
    try {
      const res  = await fetch('/api/auth/session');
      const data = await res.json();
      if (res.ok && !data.err) {
        authorized.set(true);
        user.set(data.out);
        window.location.hash = DEFAULT_ROUTE;
        return;
      }
    } catch (_) {}

    // Nessuna sessione valida: mostra login
    const showLogin = () => {
      container.innerHTML = '';
      const login = new LoginComponent();
      login.addEventListener('must-change-password', () => {
        container.innerHTML = '';
        const changepass = new ChangepassComponent();
        changepass.addEventListener('password-changed', showLogin);
        container.appendChild(changepass);
      });
      container.appendChild(login);
    };

    showLogin();
  }
};
