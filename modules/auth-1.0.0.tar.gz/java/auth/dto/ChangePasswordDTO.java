package com.example.auth.dto;

public record ChangePasswordDTO(String currentPassword, String newPassword) {}
