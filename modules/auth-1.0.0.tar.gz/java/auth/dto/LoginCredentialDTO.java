package {{APP_PACKAGE}}.auth.dto;

public record LoginCredentialDTO(String username, String password) {}
