package com.example.auth.dto;

public record ForgotPasswordDTO(String username) {}
