package {{APP_PACKAGE}}.auth.dto;

public record ForgotPasswordDTO(String username) {}
